<?php
session_start();
?>
<?php
if (!($_SESSION['LoggedIn'] == 1))
    header("Location: index.php")
    ?>
<!DOCTYPE html>
<!--
This is the home page for the website. Will allow the user to navigate to 
the various functions.
-->

<html>
    <head>
        <title>Tuck Shop</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv=”Pragma” content=”no-cache”>
        <meta http-equiv=”Expires” content=”-1″>
        <meta http-equiv=”CACHE-CONTROL” content=”NO-CACHE”>
        <!--Custom CSS-->
        <link href ="styles.css" type ="text/css" rel ="stylesheet"/>
        <link rel="shortcut icon" href="images/favicon.png">

        <!--CSS for Icons-->
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Rock+Salt" />

        <!--Scripts-->
        <script src ="scripts.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    </head>
    <body style="background-image: url('images/background.png')">
        <!--Navigation Bar------------------------------------------------------->
        <div class ="navBarLeft">
            <h2 class="hello"><?php echo "Hello " . $_SESSION['FirstName'] ?></h2>
            <form class="navSearch" action="campers.php">
                <input class="navSearchBar" type="text" placeholder="Search ..." name="camper" maxlength="30">
                <input class="navButton" type="submit" value="Search" >
            </form>
            <a href ="home.php" class="currentLink">
                <i class="fa fa-home fa-2x" title="Home"> Home</i>
            </a>
            <a href ="inventoryPage.php">
                <i class="fa fa-database fa-2x" title="Inventory"> Inventory</i>
            </a>
            <a href ="settingsPage.php">

                <i class="fa fa-cogs fa-2x" title="Settings"> Settings</i>
            </a>
            <a href="index.php">
                <i class ="fa fa-sign-out   fa-2x" title="Log Out"> Log Out</i>
            </a>
        </div>
        <div class ="navBannerDiv">
            <img alt = " " class = "navBanner" src = "images/campStore.png">
        </div>
        <!----------------------------------------------------------------------->
        <div class = "container">
            <div id="homeHeader">
                <h1 style="margin-top: 0;">Camp Seggie</h1>
                <h3 style="margin-top: 0;">Online Tuck Shop</h3>
                <i class="fa fa-sun-o fa-5x" style="color: #ffd04f;"></i>
                
                
            </div>
            
            <div id="tutorialButtonDiv">
	        <h3 style="margin-top: 20px;">New to this website?</h3>
	        <button type="button" class="button" id="showTutorialButton">Tutorial</button
            </div>
                
      	    <div id="tutorialDiv">        
            </div>
            
            <div id="homeLink"> 
                    <i class="fa fa-tree fa-2x" style="margin-top: 100px;"></i>
                    <a href="http://campseggie.ca" target="_blank">Visit the Camp Seggie Website</a>
                    <i class="fa fa-tree fa-2x"></i>
            </div>
                
                
        </div>
        <script>
        $('#showTutorialButton').click(function () {
                $('#tutorialDiv').toggle();
                console.log("toggle");
            });
        </script>
    </body>
</html>



