<?php
include('connect.php');

function get_product_name($pid) {
    //*****************
    $servername = 'localhost';
    $port = 3306;
    $username = 'root';
    $password = '';
    $db = 'seggiecampers';
    $con = mysqli_connect($servername, $username, $password, $db, $port);
    //**************** 
    $result=mysqli_query($con, "select name from products where id='".$pid."'") or die("select name from products where id='".$pid."'<br/><br/>".mysqli_error());
    $row=mysqli_fetch_array($result);
    return $row['name'];
}
function get_price($pid) {
    //*****************
    $servername = 'localhost';
    $port = 3306;
    $username = 'root';
    $password = '';
    $db = 'seggiecampers';
    $con = mysqli_connect($servername, $username, $password, $db, $port);
    //**************** 
    $result=mysqli_query($con, "select price from products where id='".$pid."'") or die("select name from products where id='".$pid."'<br/><br/>".mysqli_error());
    $row=mysqli_fetch_array($result);
    return $row['price'];
}
function remove_product($pid) {
    $pid=intval($pid);
    $max=count($_SESSION['cart']);
    for ($i=0;$i<$max;$i++) {
        if($pid==$_SESSION['cart'][$i]['productid']) {
            unset($_SESSION['cart'][$i]);
            break;
        }
    }
    $_SESSION['cart']=array_values($_SESSION['cart']);
}
function get_order_total() {
    $max=count($_SESSION['cart']);
    $sum=0;
    for ($i = 0; $i < $max; $i++) {
        $pid = $_SESSION['cart'][$i]['productid'];
        $q = $_SESSION['cart'][$i]['qty'];
        $price = get_price($pid);
        $sum += $price * $q;
    }
    return $sum;
}
function addtocart($pid, $q) { //-$q
    if($pid<1 or $q<1) return; // 1 to 0

    if(is_array($_SESSION['cart'])) {
        if(product_exists($pid)) return;
        $max=count($_SESSION['cart']);
        echo "MAX functions.php:".$max;
        $_SESSION['cart'][$max]['productid']=$pid;
        $_SESSION['cart'][$max]['qty']=$q;
    } else {
        $_SESSION['cart'] = array();
        $_SESSION['cart'][0]['productid']=$pid;
        $_SESSION['cart'][0]['qty']=$q;
    }
}
function product_exists($pid) {
    $pid=intval($pid);
    $max=count($_SESSION['cart']);
    $flag=0;
    for ($i = 0; $i < $max; $i++) {
        if ($pid == $_SESSION['cart'][$i]['productid']) {
            $flag = 1;
            break;
        }
    }
    return $flag;
}
?>
