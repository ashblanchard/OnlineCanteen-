<?php
$servername = 'localhost';
$port = 3306;
$username = 'root';
$password = '';
$db = 'seggiecampers';
// Create connection
$con = mysqli_connect($servername, $username, $password, $db, $port);
if(!isset($_SESSION['cart'])){
    session_start();
} 

    
?>