

<?php
//include 'includes/connect.php';
include 'includes/functions.php';

if (isset($_REQUEST['command'] )&& $_REQUEST['command'] == 'add' && $_REQUEST['productid'] > 0) {
    $pid = $_REQUEST['productid'];
    addtocart($pid, 1); //changed 1 to 0 
    header("location:shoppingcart.php");
    exit();
}
?>
<html>
<!DOCTYPE html"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">   
    
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Products</title>
        <script language="javascript">
            function addtocart(pid) {
                document.form1.productid.value = pid;
                document.form1.command.value = 'add';
                document.form1.submit();
            }
        </script>
    </head>
    <body>
        <form name="form1">
            <input type="hidden" name="productid" />
            <input type="hidden" name="command" />
        </form>
            <h1 align="center">Products</h1>
            
                <?php
                //$sql = 'SELECT id, name, price FROM products';
                $sql = 'SELECT id, name, price FROM products';
                $result = mysqli_query($con, $sql);
                //$row = mysqli_fetch_object($result);
                $row = mysqli_fetch_object($result);
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
 <div align="center">
           
            <table border="0" cellpadding="2px" width="600px"
                   <td> ID <?php echo $row['id']; ?>
                    <td> 
                        <td><?php echo $row['name'] ?></td><br />
                    Price:<big style="color:green">
                        $<?php echo $row['price'];
                        $q = 1; ?></big><br /><br />    
                    <input type="button" value="Add to Cart" onclick="addtocart(<?php echo $row['id']; ?>)" />
                    </td>
                    <?php// $_SESSION['cart'][$row['id']]['productid']; ?> <!--set product id session-->
                    </tr>
                    <tr><td colspan="2"><hr size="1" /></td>
                    <?php } ?>
            </table>
        </div>
    </body>
</html>