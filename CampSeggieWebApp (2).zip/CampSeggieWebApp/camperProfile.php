
<html>
    <head>
        <meta charset="UTF-8">
        <title>Tuck Shop</title>

        <!--Custom CSS-->
        <link href ="styles.css" type ="text/css" rel ="stylesheet"/>
        <link rel="shortcut icon" href="images/favicon.png">

        <!--CSS for Icons-->
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.css">

        <!--Scripts-->
        <script src ="scripts.js"></script>
    </head>
    <body>
        <div class = "container">
            <!--Navigation Bar------------------------------------------------------->
            <div class ="navigationBar">
                <span class="backButton">
                    <a href="index.php">
                        <i class="fa fa-reply-all  fa-2x" title="Back to Login">Log Out</i>
                    </a>
                </span>
                <span class="homeButton">
                    <a href ="home.php">
                        <i class="fa fa-home fa-2x" title="Home"style="margin-right: 16px;">Home</i>
                    </a>
                </span>
                <span class = "settingsButton">
                    <a href ="settingsPage.php">
                        <i class="fa fa-cogs fa-2x" title="Settings">Settings</i>
                    </a>
                </span>
                <div class ="navBannerDiv">
                    <img alt = "" class = "navBanner" src = "images/campStore.png">
                    <h1 class = "navBannerText"><!--Page Text here, If needed--></h1>
                </div>
                <hr>
            </div>
            <!----------------------------------------------------------------------->
            <body>
                <?php
                $con = mysqli_connect("localhost", "phpuser", "phpuserpw");
                if (!$con) {
                    exit('Connect Error (' . mysqli_connect_errno() . ') '
                            . mysqli_connect_error());
                }
//set the default client character set 
                mysqli_set_charset($con, 'utf-8');


                mysqli_select_db($con, "seggiecampers");
                $selectedCamper = mysqli_query($con, "SELECT * FROM campers  WHERE id='" . $_GET['camperid'] . "'");
                while ($row = mysqli_fetch_assoc($selectedCamper)) {
                    echo "<h1>" . htmlentities($row["name"]) . "<br/></h1></div>";
                    echo "<h2>Cabin: " . htmlentities($row["cabin"]) . "<br/><br></br><br></br></h2>";
                    $cabin = htmlentities($row["cabin"]);
                    if (strcmp($cabin, "STAFF") == 0) {
                        echo "<h3>Amount Due: $" . number_format(htmlentities($row["storeDeposit"]), 2) . "</h3>";
                    } else {
                        echo "<h3>Initial Balance: $" . number_format(htmlentities($row["initialBalance"]), 2) . "</h3>";
                        echo "<h3>Current Balance: $" . number_format(htmlentities($row["storeDeposit"]), 2) . "</h3>";
                    }
                }
                mysqli_close($con);
                ?>



                <h3>Current Inventory:</h3><br>
                <table border="black">
                    <div align ='left'>
                        <tr>
                            <th> ID </th>
                            <th> Item </th>
                            <th> Price </th>
                            <th> Quantity </th>
                            <th> Purchase </th>
                        </tr>
                        <?php
                        $con = mysqli_connect("localhost", "phpuser", "phpuserpw", "seggiecampers");
                        if (!$con) {
                            exit('Connect Error (' . mysqli_connect_errno() . ')  '
                                    . mysqli_connect_error());
                        }
                        $result = mysqli_query($con, "SELECT id, itemName, itemPrice, consumerPrice, quantity FROM inventory ");
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr><td>" . htmlentities($row["id"]) . "</td>";
                            echo "<td>" . htmlentities($row["itemName"]) . "</td>";
                            if (strcmp($cabin, "STAFF") == 0) {
                                echo "<td>$" . number_format(htmlentities($row["itemPrice"]), 2) . "</td>";
                            } else {
                                echo "<td>$" . number_format(htmlentities($row["consumerPrice"]), 2) . "</td>";
                            }
                            echo "<td>" . htmlentities($row["quantity"]) . "</td>";
                            echo "<td>  </td>";
                        }
                        ?>
                </table>
        </div>
    </body>

</html>
