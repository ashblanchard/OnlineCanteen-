<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
/** database connection credentials */
$dbHost = "localhost"; //on MySql
$dbUsername = "phpuser";
$dbPassword = "phpuserpw";

/** other variables */
$itemNameIsEmpty = false;
$itemPriceIsEmpty = false;
$consumerPriceIsEmpty = false;
$quantityIsEmpty = false;

/** Check that the page was requested from itself via the POST method. */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    /** Check whether the user has filled in the camper's name in the text field "user" */
    if ($_POST["itemName"] == "") {
        $itemNameIsEmpty = true;
    }
    if ($_POST["itemPrice"] == "") {
        $itemPriceIsEmpty = true;
    }
    if ($_POST["consumerPrice"] == "") {
        $consumerPrice = true;
    }
    if ($_POST["quantity"] == "") {
        $quantityPrice = true;
    }
    /** Create database connection */
    $con = mysqli_connect("localhost", "phpuser", "phpuserpw");
    if (!$con) {
        exit('Connect Error (' . mysqli_connect_errno() . ') '
                . mysqli_connect_error());
    }
//set the default client character set 
    mysqli_set_charset($con, 'utf-8');
    
    $itemName = mysqli_real_escape_string($con, $_POST['itemName']);
    $itemPrice = mysqli_real_escape_string($con, $_POST['itemPrice']);
    $consumerPrice = mysqli_real_escape_string($con, $_POST['consumerPrice']);
    $quantity = mysqli_real_escape_string($con, $_POST['quantity']);

    if (!$itemNameIsEmpty && !$itemPriceIsEmpty && !$consumerPriceIsEmpty && !$quantityIsEmpty){ 
        mysqli_select_db($con, "seggiecampers");
        mysqli_query($con, "UPDATE campers SET itemPrice = '".$itemPrice."' WHERE name='".$itemName."'");
        mysqli_query($con, "UPDATE campers SET consumerPrice = '".$consumerPrice."' WHERE name='".$itemName."'");
        mysqli_query($con, "UPDATE campers SET quantity = '".$quantity."' WHERE name='".$itemName."'");
        mysqli_close($con);
        exit;
    }
}       
?>

<html>
    <head>
        <meta charset=UTF-8">
    </head>
    <body>
        Update Item:<br>
        <form action="editItem.php" method="POST">
            Item Name: <input type="text" name="itemName"/><br/>
            <?php
            if ($itemNameIsEmpty) {
                echo ("Enter name, please!");
                echo ("<br/>");
            }
            ?> 
            Item Price: <input type="text" name="itemPrice"/><br/>
            <?php
            if ($itemNameIsEmpty) {
                echo ("Enter original price, please!");
                echo ("<br/>");
            }
            ?>
            Consumer Price: <input type="text" name="consumerPrice" />
            <?php
            if ($consumerPriceIsEmpty) {
                echo ("Enter consumer price, please!");
                echo ("<br/>");
            }
            ?>
            Quantity: <input type="text" name="quantity" />
            <?php
            if ($quantityIsEmpty) {
                echo ("Enter quantity of item please!");
                echo ("<br/>");
            }
            ?>
            <input type="submit" value="Update Item"/>
        </form>
    </body>
</html>

