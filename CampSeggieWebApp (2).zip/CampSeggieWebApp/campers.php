<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Tuck Shop</title>

        <!--Custom CSS-->
        <link href ="styles.css" type ="text/css" rel ="stylesheet"/>
        <link rel="shortcut icon" href="images/favicon.png">

        <!--CSS for Icons-->
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.css">

        <!--Scripts-->
        <script src ="scripts.js"></script>
    </head>
    <body>
        <div class="container">
            <!--Navigation Bar------------------------------------------------------->
            <div class ="navigationBar">
                <span class="backButton">
                    <a href="index.php">
                        <i class="fa fa-reply-all  fa-2x" title="Back to Login">Log Out</i>
                    </a>
                </span>
                <span class="homeButton">
                    <a href ="home.php">
                        <i class="fa fa-home fa-2x" title="Home"style="margin-right: 16px;">Home</i>
                    </a>
                </span>
                <span class = "settingsButton">
                    <a href ="settingsPage.php">
                        <i class="fa fa-cogs fa-2x" title="Settings">Settings</i>
                    </a>
                </span>
                <div class ="navBannerDiv">
                    <img alt = "" class = "navBanner" src = "images/campStore.png">
                    <h1 class = "navBannerText"><!--Page Text here, If needed--></h1>
                </div>
                <hr>
            </div>
            <!----------------------------------------------------------------------->
            <br></br>
            <center>
                <form name="seggiecampers" action="campers.php">
                    Search:
                    <input type="text" name="camper"  style = "width: 500px; height: 20px;"/>
                    <input type="submit" value="Search" />
                </form> 
            </center>
            <br></br>
            <br></br>
            <center>Search Results: <?php echo $_GET["camper"] . "<br/>"; ?>
                <br></br>
                <br></br>

                <?php
                $con = mysqli_connect("localhost", "phpuser", "phpuserpw");
                if (!$con) {
                    exit('Connect Error (' . mysqli_connect_errno() . ') '
                            . mysqli_connect_error());
                }
//set the default client character set 
                mysqli_set_charset($con, 'utf-8');
                mysqli_select_db($con, "seggiecampers");

                $camper = mysqli_real_escape_string($con, htmlentities($_GET["camper"]));

                $camperdb = mysqli_query($con, "SELECT id FROM campers WHERE name LIKE '%$camper%'");

                if (mysqli_num_rows($camperdb) < 1) {
                    exit("The person " . htmlentities($_GET["camper"]) . " is not found. Please check the spelling and try again");
                }
                $row = mysqli_fetch_row($camperdb);
                mysqli_free_result($camperdb);
                ?>
                <table border="black">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Cabin</th>
                        <th>Store Deposit</th>
                    </tr>
                    <?php
                    $result = mysqli_query($con, "SELECT id, name, cabin, storeDeposit FROM campers  WHERE name LIKE '%$camper%'");
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<tr><td>" . htmlentities($row["id"]) . "</td>";
                        echo "<td> <a href=\"camperProfile.php/?camperid=" . $row["id"] . "\">" . htmlentities($row["name"]) . "</a></td>";
                        echo "<td>" . htmlentities($row["cabin"]) . "</td>";
                        echo "<td>" . htmlentities($row["storeDeposit"]) . "</td></tr>\n";
                    }
                    mysqli_free_result($result);
                    mysqli_close($con);
                    ?>
                </table>
            </center>
        </div>
    </body>
</html>