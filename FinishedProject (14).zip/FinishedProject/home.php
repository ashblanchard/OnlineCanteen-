<?php
session_start();
?>
<?php
if (!($_SESSION['LoggedIn'] == 1))
    header("Location: index.php")
    ?>
<!DOCTYPE html>
<!--
This is the home page for the website. Will allow the user to navigate to 
the various functions.
-->

<html>
    <head>
        <title>Tuck Shop</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv=”Pragma” content=”no-cache”>
        <meta http-equiv=”Expires” content=”-1″>
        <meta http-equiv=”CACHE-CONTROL” content=”NO-CACHE”>
        <!--Custom CSS-->
        <link href ="styles.css" type ="text/css" rel ="stylesheet"/>
        <link rel="shortcut icon" href="images/favicon.png">

        <!--CSS for Icons-->
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Rock+Salt" />

        <!--Scripts-->
        <script src ="scripts.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    </head>
    <body id="homeBody">
        <!--Navigation Bar------------------------------------------------------->
        <div class ="navBarLeft">
            <h2 class="hello"><?php echo "Hello " . $_SESSION['FirstName'] ?></h2>
            <form class="navSearch" action="campers.php">
                <input class="navSearchBar" type="text" placeholder="Search ..." name="camper" maxlength="30">
                <input class="navButton" type="submit" value="Search" >
            </form>
            <a href ="home.php" class="currentLink">
                <i class="fa fa-home fa-2x" title="Home"> Home</i>
            </a>
            <a href ="inventoryPage.php">
                <i class="fa fa-database fa-2x" title="Inventory"> Inventory</i>
            </a>
            <a href ="settingsPage.php">

                <i class="fa fa-cogs fa-2x" title="Settings"> Settings</i>
            </a>
            <a href="index.php">
                <i class ="fa fa-sign-out   fa-2x" title="Log Out"> Log Out</i>
            </a>
        </div>
        <div class ="navBannerDiv">
            <img alt = " " class = "navBanner" src = "images/campStore.png">
        </div>
        <!----------------------------------------------------------------------->
        <div class = "container">
            <div id="homeHeader">
                <h1 style="margin-top: 0;">Camp Seggie</h1>
                <h3 style="margin-top: 0;">Online Tuck Shop</h3>
                <i class="fa fa-sun-o fa-5x" style="color: #ffd04f;"></i>
            </div>

            <div id="tutorialButtonDiv">
                <h3 style="margin-top: 70px;">New to this website?</h3>
                <button type="button" class="button" id="showTutorialButton">Tutorial</button>
            </div>

            <div id="tutorialDiv" class=" ">
                <div class="tutorialContainer">
                    <div class="tutorialHeader">
                        <h1>Searching Campers</h1>
                    </div>
                    <div class="tutorialPara">
                        <p>
                            Use the search bar to search the database for Campers or Staff Members.
                        </p>
                    </div>
                    <div class="tutorialImage">
                        <img src="images/search.PNG">
                    </div>
                </div>

                <div class="tutorialContainer">
                    <div class="tutorialHeader">
                        <h1>Adding/Removing Campers/Staff</h1>
                    </div>
                    <div class="tutorialPara">
                        <p>
                            The Settings page contains many functions for adding campers or staff members, or creating new users for the application. 
                            Use the View all Campers, or View all Staff buttons to view the current lists of campers and staff in the database. 
                            Manually add campers or staff members to the database from the settings page, or update their information. 
                            Also, create new users from the settings page, as well as change the password of the user logged in. 
                        </p>
                    </div>
                    <div class="tutorialImage">
                        <img src="images/settingsPage.PNG">
                        <br>
                        <img src="images/add.PNG">
                        <br>
                        <img src="images/showDatabases.PNG" style="width: 70%;">
                        <br>
                        <img src="images/buttonss.PNG">
                    </div>
                </div>

                <div class="tutorialContainer">
                    <div class="tutorialHeader">
                        <h1>Managing Inventory</h1>
                    </div>
                    <div class="tutorialPara">
                        <p>
                            The Inventory page has functions for adding new items, as well as editing and removing current items.
                            Any items whose quantity is 20 or lower, will appear in red on the inventory page to alert the user of a low inventory.
                        </p>
                    </div>
                    <div class="tutorialImage">
                        <img src="images/inventory.PNG">
                        <br>
                        <img src="images/additem.PNG">
                        <br>
                        <img src="images/editRemove.PNG" style="width: 70%;">
                    </div>
                </div>

                <div class="tutorialContainer">
                    <h1>Performing Purchases</h1>
                    <div class="tutorialPara">
                        <p>
                            To perform a purchase for a Camper/Staff, follow these steps.
                        <ol>
                            <li>
                                Search a Camper/Staff's name using the search bar on the left.
                            </li>
                            <li>
                                Click on the appropriate name to go to the individual's profile.
                            </li>
                            <li>
                                The individual's initial balance and current balance can be viewed on their profile.
                            </li>
                            <li>
                                Add items to the individual's cart using the ADD TO CART button under the INVENTORY.
                            </li>
                            <li>
                                Under the CART section, current items will be displayed, along with the total price of each item, and the overall total price of the items in the cart.
                                <br>-The CLEAR CART button can be used to remove all current items from the cart.
                                <br>-The UPDATE CART button is used for when the quantity of an item in the cart has been changed. If you change the quantity of an item, you must click the update cart button before checkout.
                            </li>
                            <li>
                                The CHECKOUT button will perform the purchase, and update the indivdual's current balance accordingly.
                            </li>
                            <li>
                                Using the PREVIOUS RESULTS button will clear all items from the individual's cart, and navigate back to the list of Campers/Staff.
                            </li>
                                
                            
                        </ol>

                        </p>
                    </div>
                    <div class="tutorialImage">
                        <img src="images/search.PNG">
                        <br>
                        <img src="images/name.PNG">
                        <br>
                        <img src="images/balance.PNG">
                        <br>
                        <img src="images/addtocart.PNG">
                        <br>
                        <img src="images/cart.PNG">
                        <br>
                        <img src="images/clear.PNG">
                        <br>
                        <img src="images/update.PNG">
                        <br>
                        <img src="images/checkout.PNG">
                        <br>
                        <img src="images/previous.PNG">
                    </div>
                </div>
            </div>


            <div id="homeLink"> 
                <i class="fa fa-tree fa-2x" style="margin-top: 100px;"></i>
                <a href="http://campseggie.ca" target="_blank">Visit the Camp Seggie Website</a>
                <i class="fa fa-tree fa-2x"></i>
            </div>

        </div> 

        <script>
            $('#showTutorialButton').click(function () {
                $("#tutorialDiv").toggleClass("display-inline");
                console.log("toggle");
            });

        </script>
    </body>
</html>



