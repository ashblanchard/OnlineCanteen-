<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Login Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href ="styles.css" type ="text/css" rel ="stylesheet"/>
        <script src ="scripts.js"></script>
        <script src="data.js"></script>
    </head>
    <body>
        <div class = "container">            
            <br><br><br><br><br>
            <br><br><br><br><br>
            <br><br><br><br><br>

                <div id ="passwordDiv">
                <form id ="passwordForm" name="frm" method="post" action="home.php">
                    <h3>Enter Password</h3><br>
                    <input id ="passwordBox" type ="password" name="userpass" style = "width: 500px; height: 30px;">
                    &nbsp;&nbsp;<input type="submit" id ="btn" value="Submit" onclick="return val();" />
                    <br/><br/>
                    &nbsp;&nbsp;<input type="reset" value="Reset" />
                </form>
            </div>
            <img alt="" src="images/campStore.png">
        </div>
    </body>
</html>