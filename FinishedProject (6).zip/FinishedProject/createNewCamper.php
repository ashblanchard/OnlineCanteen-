<?php
session_start();
?>
<?php
if (!($_SESSION['LoggedIn'] == 1))
    header("Location: index.php")
    ?>
<!DOCTYPE html><!--NEW-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv=”Pragma” content=”no-cache”>
        <meta http-equiv=”Expires” content=”-1″>
        <meta http-equiv=”CACHE-CONTROL” content=”NO-CACHE”>
        <title>Tuck Shop</title>

        <!--Custom CSS-->
        <link href ="styles.css" type ="text/css" rel ="stylesheet"/>
        <link rel="shortcut icon" href="images/favicon.png">

        <!--CSS for Icons-->
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="fontAwesome/css/font-awesome.css">

        <!--Scripts-->
        <script src ="scripts.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    </head>
    <body>
        <!--Navigation Bar------------------------------------------------------->
        <div class ="navBarLeft">
            <h2 class="hello"><?php echo "Hello " . $_SESSION['FirstName'] ?></h2>
            <form class="navSearch" action="campers.php">
                <input class="navSearchBar" type="text" placeholder="Search Campers..." name="camper">
                <input class="navButton" type="submit" value="Search" >
            </form>
            <a href ="home.php">
                <i class="fa fa-home fa-2x" title="Home"> Home</i>
            </a>
            <a href ="inventoryPage.php">
                <i class="fa fa-database fa-2x" title="Inventory"> Inventory</i>
            </a>
            <a href ="settingsPage.php"class="currentLink">

                <i class="fa fa-cogs fa-2x" title="Settings"> Settings</i>
            </a>
            <a href="index.php">
                <i class ="fa fa-sign-out   fa-2x" title="Log Out"> Log Out</i>
            </a>
        </div>
        <div class ="navBannerDiv">
            <img alt = " " class = "navBanner" src = "images/campStore.png">
        </div>
        <div class="backToTop">
            <a href="#top">
                <i class="fa fa-angle-double-up fa-2x"></i>
            </a>
        </div>
        <!----------------------------------------------------------------------->
        <div class = "container">

            <?php
            require_once("Includes/db.php");

            /** other variables */
            $nameIsEmpty = false;
            $cabinIsEmpty = false;
            $store_depositIsEmpty = false;
            $store_depositIsInteger = false;
            $errorMessage = "";

            /** Check that the page was requested from itself via the POST method. */
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                /** Check whether the user has filled in the camper's name in the text field "user" */
                if ($_POST["name"] == "") {
                    $nameIsEmpty = true;
                }
                if ($_POST["camperCabin"] == "") {
                    $cabinIsEmpty = true;
                }
                if ($_POST["store_deposit"] == "") {
                    $store_depositIsEmpty = true;
                }
                $storeDeposit = $_POST["store_deposit"];
                $newStoreDeposit = trim($storeDeposit, '$');

                if (is_numeric($newStoreDeposit)) {
                    $store_depositIsInteger = true;
                    $errorMessage = "Store Deposit has to be numeric. Please try again.";
                }

                if (!$nameIsEmpty && !$cabinIsEmpty && !$store_depositIsEmpty && $store_depositIsInteger) {
                    SeggieDB::getInstance()->create_new_camper($_POST["name"], $_POST["camperCabin"], $newStoreDeposit);
                    echo "<h1>Success</h1>";
                    echo "Camper successfully added to database."; 
                } else {
                    echo "<h1>Error</h1>";
                    echo "Camper could not be added to database. Please try again.";
            }}
            ?> 
            <br>
            <a href="settingsPage.php">
                <button class="button" style="margin-top: 10%;">Back</button>
            </a>

        </div>
    </body>
</html>