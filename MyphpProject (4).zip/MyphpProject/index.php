<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title>Camp Seggie's Online Canteen</title>
    <center>
        <img src="u7.jpg" alt="homeheader" style ="width:width;height:height;">
        <h1> Welcome to Camp Seggie's Online Canteen </h1>
    </head>
    <body>
        <form name="seggiecampers" action="campers.php">
            Search Directory:
            <input type="text" name="camper" />
            <input type="submit" value="Search" />
        </form>  
</center>
<br></br>
<br></br>
<br></br>
<br>Settings Page: <a href="settingsPage.php">Go</a>

</body>
</html>


