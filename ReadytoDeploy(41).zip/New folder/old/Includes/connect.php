<?php
if(!isset($_SESSION['cart'])){
    session_start();
} 
?>