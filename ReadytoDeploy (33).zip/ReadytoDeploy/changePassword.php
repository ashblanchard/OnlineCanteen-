<?php
$newPasswordDifferent = false;
$invalidPassword = false;

include "Includes/connect.php";
echo "hasldfkasldkfjsafs";
echo $_POST['oldPass1'] . "  " . $_POST['newPass1'] . "   " . $_POST['newPass2'];
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if ((strcmp($_POST['newPass1'],$_POST['newPass2'])) != 0) {
        $newPasswordDifferent = true;
        echo "passwords different.";
    }if (strlen($_POST['newPass1']) < 6) {
        $invalidPassword = true;
        echo "less than 6";
    }if (!$newPasswordDifferent && !$invalidPassword) {
        $password = md5($_POST['newPass1']);
        mysql_query("UPDATE users SET Password = '" . $password . "' WHERE Username = '" . $_SESSION['Username'] . "'");
        //header('Location: settingsPage.php');
        //exit;
    }
     else {
         echo "no.";
     }
         
}
?>

