<?php
$newPasswordDifferent = false;

include "base.php";
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (strcmp($_POST['newPass1'],$_POST['newPass2'])) {
        $newPasswordDifferent = true;
    }if (!$newPasswordDifferent) {
        mysql_query("UPDATE users SET Password = '" . $_POST['newPass1'] . "' WHERE Password = '" . $_POST['oldPass1'] . "'");
        header('Location: settingsPage.php');
        exit;
    }
     else {
         echo "no.";
     }
         
}
?>

