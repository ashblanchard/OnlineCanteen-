<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
/** database connection credentials */
$dbHost = "localhost"; //on MySql
$dbUsername = "phpuser";
$dbPassword = "phpuserpw";

/** other variables */
$first_nameIsEmpty = false;
$last_nameIsEmpty = false;
$cabinIsEmpty = false;
$store_depositIsEmpty = false;

/** Check that the page was requested from itself via the POST method. */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    /** Check that the page was requested from itself via the POST method. */
    /** Check whether the user has filled in the camper's name in the text field "user" */
    if ($_POST["first_name"] == "") {
        $first_nameIsEmpty = true;
    }
    if ($_POST["last_name"] == "") {
        $last_nameIsEmpty = true;
    }
    if ($_POST["camperCabin"] == "") {
        $cabinIsEmpty = true;
    }
    if ($_POST["first_name"] == "") {
        $store_depositIsEmpty = true;
    }
    /** Create database connection */
    $con = mysqli_connect("localhost", "phpuser", "phpuserpw");
    if (!$con) {
        exit('Connect Error (' . mysqli_connect_errno() . ') '
                . mysqli_connect_error());
    }
//set the default client character set 
    mysqli_set_charset($con, 'utf-8');
    
    $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
    $camperCabin = mysqli_real_escape_string($con, $_POST['camperCabin']);
    $store_deposit = mysqli_real_escape_string($con, $_POST['store_deposit']);

     
        mysqli_select_db($con, "seggiecampers");
        mysqli_query($con, "INSERT campers (firstName, lastName, cabin, storeDeposit) VALUES ('" . $first_name . "', '" . $last_name . "', '" . $camperCabin . "', '" . $store_deposit. "')");
        mysqli_free_result($camperdb);
        mysqli_close($con);
        header('Location: camperProfile.php');
        exit;
    
}       
?>

<html>
    <head>
        <meta charset=UTF-8">
    </head>
    <body>
        Add New Camper:<br>
        <form action="createNewCamper.php" method="POST">
            First Name: <input type="text" name="first_name"/><br/>
            <?php
            if ($first_nameIsEmpty) {
                echo ("Enter camper's first name, please!");
                echo ("<br/>");
            }
            ?> 
            Last Name:  <input type="text" name="last_name"/><br/>
            <?php
            if ($last_nameIsEmpty) {
                echo ("Enter camper's last name, please!");
                echo ("<br/>");
            }
            ?>
            Cabin: <input type="text" name="camperCabin"/><br/>
            <?php
            if ($cabinIsEmpty) {
                echo ("Enter camper's cabin, please!");
                echo ("<br/>");
            }
            ?>
            Store Deposit: <input type="text" name="store_deposit" />
            <?php
            if ($store_depositIsEmpty) {
                echo ("Enter camper's store deposit, please!");
                echo ("<br/>");
            }
            ?>
            <input type="submit" value="Add Camper"/>
        </form>
    </body>
</html>


