<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Camp Seggie's Online Canteen</title>
    </head>
    <body>
        <form name="seggiecampers" action="campers.php">
            Search Directory:
            <input type="text" name="camper" />
            <input type="submit" value="Search" />
        </form>   
            <br>New Camper:<a href="createNewCamper.php">Add to Database</a>
    </body>
</html>
