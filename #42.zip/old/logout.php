
<?php include "base.php";
$_SESSION = array();
session_destroy(); ?>
<meta http-equiv="refresh" content="0;index.php">

